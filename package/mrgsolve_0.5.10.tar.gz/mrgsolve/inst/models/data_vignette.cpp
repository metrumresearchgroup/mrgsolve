

$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CL/VC)*CENT - (Q/VC)*CENT + (Q/VP)*PERIPH;
dxdt_PERIPH = (Q/VC)*CENT  - (Q/VP)*PERIPH;


$TABLE
table(CP) = CENT/VC;


