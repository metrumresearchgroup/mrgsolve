
$PARAM  KA = 0.5, CL = 1, VC = 10
$INIT    GUT = 0, CENT = 0
$SET end=36, delta=0.5


$MAIN
double CLi = CL*exp(ETA(1));
double VCi = VC*exp(ETA(2));

$OMEGA corr=TRUE
0.1
0.7 0.3

$SIGMA 0.1

$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CLi/VCi)*CENT;

$TABLE
table(IPRED) = CENT/VCi;
table(DV) = table(IPRED) *exp(EPS(1));
table(ETA1) = ETA(1);

