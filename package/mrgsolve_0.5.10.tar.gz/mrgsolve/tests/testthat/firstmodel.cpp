#include "firstmodel.h"

// @param: CL=1, VC=20, KA=0.2
// @init: DEPOT = 1000, CENT = 0
// @end: 72
// @delta: 0.25

BEGIN_ode
  dxdt_DEPOT = -KA*DEPOT;
  dxdt_CENT = KA*DEPOT - (CL/VC)*CENT;
END_ode

BEGIN_table
   table(CP) = CENT/VC;
END_table
