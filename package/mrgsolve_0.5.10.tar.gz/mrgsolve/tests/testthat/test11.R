library(mrgsolve)
library(testthat)
require(dplyr)

Sys.setenv(R_TESTS="")

project <- file.path(system.file(package="mrgsolve"), "models")

context("Testing infusion inputs")

code <-'

$PARAM CL=1, VC=30, KA=1.2, SET=7
$CMT GUT CENT

$MAIN 
_R(1) =  SET;

$OMEGA
0

$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CL/VC)*CENT;
'

mod <- mread(code=paste0(code), model="infusion") %>%
  update(end=72) %>% obsonly


data <- expand.ev(ID=1:5,rate=c(1,5,10,50), amt=100)
set.seed(1212)
out0 <- mod %>% data_set(data) %>% mrgsim

data <- data %>% mutate(SET = rate, rate=-1)
set.seed(1212)
out <- mod %>% data_set(data) %>% mrgsim



test_that("Infusion rate is set by _R(n)", {
    expect_identical(out0$CENT, out$CENT)
})

data$rate <- -2
test_that("Error when rate = -2 and _R(n) set instead of _D(n)", {
    expect_error(mod %>% data_set(data) %>% mrgsim)
})



code <-'

$PARAM CL=1, VC=30, KA=1.2, SET=0
$CMT GUT CENT

$MAIN 
_D(1) =  SET;

$OMEGA
0

$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CL/VC)*CENT;
'


mod <- mread(code=code, model="_D") %>%
  update(end=120) %>% obsonly


data0 <- expand.ev(ID=1:3,dur=c(2,5,10,50), amt=100) %>%
  mutate(rate = amt/dur)

set.seed(1212)
out0 <- mod %>% data_set(data0) %>% mrgsim

data <- data0 %>% mutate(SET = dur, rate=-2)
set.seed(1212)
out <- mod %>% data_set(data) %>% mrgsim

test_that("Infusion rate is set by _D(n)", {
  expect_identical(out0$CENT, out$CENT)
})

data$rate <- -1
test_that("Error when rate = -1 and _D(n) set instead of _R(n)", {
  expect_error(mod %>% data_set(data) %>% mrgsim)
})


code <- '
$PARAM D1 = 2, F1=1
$MAIN _D(1) = D1; _F(1) = F1;
$CMT CENT
$ODE dxdt_CENT = -0.1*CENT;
'
mod <- mread(code=code, "test11DF",tempdir())

out <- mod %>% ev(amt=1000,  rate=-2) %>% mrgsim
out2 <- mod %>% ev(amt=1000, rate=-2, F1=0.5) %>% mrgsim
out3 <- mod %>% ev(amt=1000, rate=-2, D1 = 10) %>% mrgsim
out4 <- mod %>% ev(amt=1000, rate=-2, D1 = 10,F1=1.5) %>% mrgsim

test_that("Correct infusion duration when _D and _F are set", {
  expect_true(out$time[which.max(out$CENT)] ==2)
  expect_true(out2$time[which.max(out2$CENT)]==2)
  expect_true(round(max(out$CENT)/max(out2$CENT),3) == 2)
  expect_true(out3$time[which.max(out3$CENT)]==10)
  expect_true(out4$time[which.max(out4$CENT)]==10)
  expect_true(round(max(out3$CENT)/max(out4$CENT),3) == 0.667)
})



code <- '
$PARAM R1 = 100, F1=1
$MAIN _R(1) = R1; _F(1) = F1;
$CMT CENT
$ODE dxdt_CENT = -0.1*CENT;
'

mod <- mread(code=code, "test11RF",tempdir()) %>% update(delta=0.1)

out <- mod %>% ev(amt=1000,  rate=-1) %>% mrgsim
out2 <- mod %>% ev(amt=1000, rate=-1, F1=0.5) %>% mrgsim
out3 <- mod %>% ev(amt=1000, rate=-1, R1 = 50) %>% mrgsim
out4 <- mod %>% ev(amt=1000, rate=-1, R1 = 200, F1=1.5) %>% mrgsim

test_that("Correct infusion duration when _R and _F are set", {
  expect_true(out$time[which.max(out$CENT)] ==10)
  expect_true(out2$time[which.max(out2$CENT)]==5)
  expect_true(round(max(out$CENT)/max(out2$CENT),3) > 1)
  expect_true(out3$time[which.max(out3$CENT)]==20)
  expect_true(out4$time[which.max(out4$CENT)]==7.5)
  expect_true(round(max(out3$CENT)/max(out4$CENT),3) < 1)
})





