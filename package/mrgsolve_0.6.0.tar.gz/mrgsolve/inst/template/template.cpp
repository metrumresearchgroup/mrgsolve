$PARAM
CL=1

$INIT CENT=0

$SET end=25, delta=1

// like $PK
$MAIN

// like $DES
$ODE

// like $ERROR and $TABLE
$TABLE






