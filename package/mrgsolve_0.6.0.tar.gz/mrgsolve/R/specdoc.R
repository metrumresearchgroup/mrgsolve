## This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
## To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/ or send a letter to
## Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.



##' Model Specification File
##'
##' @name modelspec
##' @rdname modelspec
##'
##' @section CODE BLOCKS:
##'
##' The following list gives the names and usage for different code blocks in the mrgsolve model specification file.  All code blocks start with \code{$} .
##'
##' \itemize{
##'
##'  \item \bold{\code{$PROB}} include a description of the model; the value supplied here must resolve to a valid character string when parsed by the R parser
##' \item \bold{\code{$PARAM}} name/value pairs for parameters; these name/value pairs for inits must be valid input for \code{list()} when parsed.  Parameters listed in \code{$PARAM} are numeric variables
##' that can be used in \code{$MAIN}, \code{$ODE},  \code{$TABLE}, or \code{$CAPTURE} and, importantly, can be updated from \code{R} without recompiling the model.
##' \item \bold{\code{$FIXED}} include name/value pairs exactly as you would in \code{$PARAM}.  However, these values are declared as constant doubles in the C++ code and are not able to be updated from the R side. This is
##' usually only implemented when there are a very large number of parameters, some of which are never updated.  Moving these parameters to \code{$FIXED} will decrease the "active" number of parameters resulting
##' in minor efficiency gains during simulation but much better clarity when looking at the parameter list with \code{\link{param}}.  A
##' call to \code{\link{param}} will only show name/value pairs declared in \code{$PARAM}.  Call \code{\link{allparam}} to get all name/values declared in \code{$PARAM} and \code{$FIXED}.
##' \item \bold{\code{$INIT}} name/value pars for compartments / initial conditions; these name/value pairs for inits must be valid input for \code{list()} when parsed.
##' \item \bold{\code{$CMT}} an alternative to \code{$INIT}; specify compartment names only; enter unquoted strings;  may be separated by whitespace, comma, or newline.  Initial conditions are assumed to be zero and result is stored and accessed as $INIT would be.
##' \item \bold{\code{$SET}} run settings, as name/value pairs; these name/value pairs must be valid input for \code{list()} when parsed; value must be a scalar numeric or logical value; modify settings for simulation start or end time, simulation time interval, solver settings (e.g. tolerances or max step size), number of significant digits in output, etc.
##' \item \bold{\code{$GLOBAL}} code that will get executed upon compile, outside of any other block; must be valid C++ code, may use C++ VARIABLES and MACROS provided by mrgsolve
##' \item \bold{\code{$MAIN}} main function (like NONMEM $PK); must be valid C++ code.
##' \item \bold{\code{$ODE}} differential equations (like NONMEM $DES); must be valid C++ code, may use C++ VARIABLES and MACROS provided by mrgsolve
##' \item \bold{\code{$TABLE}} table function (like NONMEM $ERROR + $TABLE); must be valid C++ code, may use C++ VARIABLES and MACROS provided by mrgsolve
##' \item \bold{\code{$ADVAN2}} implement one-compartment PK model with first-order absorption, where compartment amounts are calculated from algebraic equations rather than ODEs.  Initialize two compartments in \code{$CMT}, where the first compartment is the dosing depot.  Set \code{pred_CL}, \code{prec_VC}, and \code{pred_KA} in \code{$MAIN}.
##' \item \bold{\code{$ADVAN4}} implement two-compartment PK model with first-order absorption, where compartment amounts are calculated from algebraic equations rather than ODEs.  Initialize three compartments in \code{$CMT}, where the first compartment is the dosing depot and the second is the central compartment.  Set \code{pred_CL}, \code{pred_V2}, \code{pred_Q}, \code{pred_V3}, and \code{pred_KA} in \code{$MAIN}.
##' \item \bold{\code{$NMXML}} read in NONMEM modeling results; provide either project directory with run number or the full path to the .xml results file.  Will read in final THETAs and add those to the parameter list. See \code{\link{nmxml}} for options that can be set in \code{$NMXML}.  To load model elements directly from a NONMEM run with \code{$NMXML}, it is required to have the \code{XML} package
##' installed in your packages library.
##'
##' \item \bold{\code{$THETA}} numeric values that will be added to the parameter list.
##'  \item \bold{\code{$OMEGA}} a matrix for subject-level random effects.  See \code{\link{modMATRIX}} for options that can be set in \code{$OMEGA}.
##' \item \bold{\code{$SIGMA}} a matrix for residual unexplained variability.  See \code{\link{modMATRIX}} for options that can be set in \code{$SIGMA}.
##' \item \bold{\code{$ENV}} environment variables; referencing environment variables is currently only implemented in $NMXML.
##' \item \bold{\code{$CMTN}} To get the number of specific compartments (CMT), specify names here as unquoted comma-separated list; they will be made
##' available in the C++ code as _N_CMT.
##' \item \bold{\code{$CAPTURE}} names of \code{C++} variables to capture in simulated output; separate by comma, space or newline. Each variable listed in this block will be passed to the \code{capture} macro discussed below.
##' \item \bold{\code{$PKMODEL}} implement a one- or two- compartment PK model with analytical solution.  See \code{\link{PKMODEL}} for options.
##' }
##'
##'
##'
##'
##' @section Variables:
##'
##' \itemize{
##'  \item parameters are accessible by name as specified in \code{param(mod)}; readonly except in \code{main} block iniated by \code{BEGIN_mainW};  TYPE: \code{double}
##'  \item amount in a compartment is accessible by compartment name as specified in \code{init(mod)}; readonly. TYPE: \code{double}
##'  \item for the \code{n}th compartment \code{CMT}, set the bioavailability fraction to \code{F_CMT}.  This is an alias to \code{_F(n)} (see below).
##'  \item for the \code{n}th compartment \code{CMT}, set the dosing lag time to \code{ALAG_CMT}.  This is an alias to \code{_ALAG(n)} (see below).
##'  \item for the \code{n}th compartment \code{CMT}, set the infusion rate to \code{R_CMT}.  This is an alias to \code{_R(n)} (see below).
##'  \item for the \code{n}th compartment \code{CMT}, set the infusion duration to \code{D_CMT}.  This is an alias to \code{_D(n)} (see below).
##'  \item the initial amount in compartment \code{CMT} is accessible by \code{CMT_0}.  TYPE: \code{double}
##'  \item \code{EVID}: event id (0: observation, 1: dosing event; 2: other type event; 3: reset; 8: replace).  TYPE: \code{int}
##'  \item \code{TIME}: the time value of current record.  TYPE: \code{double}
##'  \item \code{SOLVERTIME}: the current value of time within the ode solver.  TYPE: \code{double}
##'  \item \code{NEWIND}: new individual flag (0: first record of data set; 1: first record of current individual; 2: subsequent records after and NEWIND 1 record).  TYPE: \code{int}
##'  \item \code{ID}: current subject ID.  TYPE: \code{double}.
##'}
##' @section Macros:
##' \itemize{
##'  \item \code{_F(n)} bioavailability fraction for \code{n}th compartment; may be read or written to in \code{main} code block.  See \code{F_CMT} above.
##' \item \code{_ALAG(n)} dosing event (evid=1) lag time.  See \code{ALAG_CMT} above.
##'  \item \code{_R(n)} infusion rate into the \code{n}th compartment. See \code{R_CMT} above.
##'  \item \code{_D(n)} infusion duration into the \code{n}th compartment.  See \code{D_CMT} above.
##'  \item \code{table(name) = value;} save value to the output simulation matrix with name \code{text}; readonly.  Only available in \code{table} code block.
##'  \item \code{ETA(n)} the value of the \code{n}th \code{ETA} drawn from normal distribution with mean \code{zero} and variance-covariance matrix \code{omega}; readonly.
##'  \item \code{EPS(n)} the value of the \code{n}th \code{EPS} drawn from normal distribution with mean \code{zero} and variance-covariance matrix \code{sigma}; readonly.
##'   \item \code{SYSTEMSTOPADVANCING()} {stop advancing the problem for current individual; all compartments will retain the same value for all subsequent simulation times,
##'   and the \code{table} block will not be called.  System will always be advancing when a new individual problem is started.}
##'   \item \code{SYSTEMNOTADAVANCING()} returns bool (logical) if system is not currently advancing.
##' \item \code{_nEQ} the number of compartments / differential equations in the problem
##' \item \code{capture(var)} writes the C++ variable \code{var} to the table of simulated output.
##' }
##'
##'
##' @section User-defined variables:
##' Users may define any valid C++ variable in the \code{$GLOBAL} code block.  These variables will be global to the problem and may be read or written to in any other code block.  User may also declare and use the C++ variables \code{double}, \code{int}, and \code{bool} in the \code{$MAIN}, \code{$ODE}, and \code{$TABLE} code blocks.  These user variables will be declared in the global environment so that they will also be global to the problem.  To use a varible that is local to one of these code blocks, use type \code{localdouble}, \code{localint}, and \code{localbool} for \code{double}, \code{int}, and \code{bool}, respectively, or create your own \code{typedef}s to avoid declaring the variables as \code{double}, \code{int} or \code{bool}.
##'
##' @section Comments:
##' \itemize{
##'  \item a double forward slash (\code{//}) will comment to the end of the line in any code block.  This is the preferred commenting mechanism.
##' }
##'
##' @section Reserved words:
##' A listing of reserved words can be printed to the \code{R} console with the function \code{\link[mrgsolve]{reserved}}.
##'
##'@examples
##'
##' code <- '
##'
##' $PROB 1-cmt model with first order absorption
##'
##' $SET delta =0.1, end=120, verbose=TRUE
##' preclean=TRUE
##'
##' $OMEGA block=TRUE
##' 0.1
##' 0.001 0.3
##'
##' $OMEGA corr=TRUE
##' 0.1
##' 0.67 0.2
##'
##' $SIGMA
##' 1 0.1
##'
##' $PARAM
##' CL=1, VC=10, KA=0.1
##'
##' $INIT GUT=0
##' CENT=1
##'
##' $GLOBAL
##' bool cool=true;
##' #define KE (CL/VC)
##'
##' $ODE
##' double CP = CENT/VC;
##'
##' dxdt_GUT = -KA*GUT;
##' dxdt_CENT = KA*GUT - KE*CENT;
##'
##' $TABLE
##'
##' table(ke) = CL/VC;
##'
##' capture(CP);
##'
##' '
##'
##'
##'
##' mod <- mread(code=code, project=tempdir())
##'
##' smat(mod)
##' omat(mod)
##' as.matrix(omat(mod))
##'
##' see(mod)
##'
##'
##' code <- '
##' $PARAM CL = 1.5, VC=35, KA=1.2
##'
##' $CMT DEPOT CENT
##'
##' $ADVAN2
##'
##' $MAIN
##' pred_CL = CL;
##' pred_VC = VC;
##' pred_KA = KA;
##' '
##'
##'
##'
##'
##'
##' mod <- mread(code=code, "ADVAN2", tempdir())
##'
##' mod %>%
##'   ev(amt=100,ii=24, addl=9) %>%
##'   mrgsim(delta=0.1,end=240) %>%
##'   plot
##'
##'
NULL


