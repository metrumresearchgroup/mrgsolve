
#library(metrumrg)
library(testthat)
#library(MASS)
library(mrgsolve)

Sys.setenv(R_TESTS="")
options("mrgsolve_mread_quiet"=TRUE)

mrgsolve:::comp_forget()
rm(list=ls())

cmt1 <- '
$PARAM CL=1, V=10, KA=2
$CMT GUT CENT  
$SUBROUTINES advan=x, trans=y
'

cmt2 <- '
$PARAM CL=1, V2 = 20, Q = 12, V3 = 300, KA=1
$CMT GUT CENT PERIPH
$SUBROUTINES advan=x, trans=y
'




