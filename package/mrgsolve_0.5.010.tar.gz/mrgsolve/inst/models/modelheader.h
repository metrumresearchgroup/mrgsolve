
#ifdef MODELINCLUDEGUARD

#endif


#ifndef MODELINCLUDEGUARD

#include <iostream>
#include <vector>
#include <map>
#include <string>
#include <math.h>

typedef  std::vector<double> dvec;
typedef  const std::vector<double> cdvec;
typedef  std::map<std::string,double> sd_map;
typedef  const std::map<std::string,double> csd_map;

// Make sure this looks like the one in the mrgsolve code:
struct databox {
  bool PRESET;
  const unsigned int newind;
  const double time;
  const int evid;
  const dvec EPS;
  const dvec ETA;
  bool SYSTEMOFF;
  const bool solving;
  bool INITSOLV;
  dvec mtime;
  const double ID;
  bool CFONSTOP;
};


#define MRGSOLVE_INIT_SIGNATURE  dvec& _A_0_,const double* _A_, cdvec& _THETA_, dvec& _F_, dvec& _ALAG_, dvec& _R_,  databox& _databox_

#define MRGSOLVE_TABLE_SIGNATURE const double* _A_, dvec& _A_0_,  cdvec& _THETA_,  dvec& _F_, dvec& _R_, sd_map& _tabledata_, databox& _databox_

#define MRGSOLVE_INIT_SIGNATUREW  dvec& _A_0_, dvec& _THETA_, dvec& _F_, dvec& _R_,  databox& _databox_

#define MRGSOLVE_ODE_SIGNATURE const  double* _ODETIME_, const double* _A_, double* _DADT_,  const dvec& _A_0_, cdvec _THETA_

#define BEGIN_ode extern "C" {void ODEFUN___(MRGSOLVE_ODE_SIGNATURE){
#define END_ode DONE

#define BEGIN_main extern "C" {void INITFUN___(MRGSOLVE_INIT_SIGNATURE){
#define BEGIN_mainW extern "C" {void INITFUN___(MRGSOLVE_INIT_SIGNATUREW){
#define END_main DONE


#define BEGIN_table extern "C" {void TABLECODE___(MRGSOLVE_TABLE_SIGNATURE) {
#define END_table DONE

#define DONE }}


#define NEWIND _databox_.newind
#define TIME _databox_.time
#define SOLVERTIME _ODETIME_[0]
#define EVID _databox_.evid
#define ID _databox_.ID

#define table(a) _tabledata_[#a]

#define _F(a) _F_.at(a-1)
#define _R(a) _R_.at(a-1)
#define _ALAG(a) _ALAG_.at(a-1)
#define ETA(a) _databox_.ETA.at(a-1)
#define EPS(a) _databox_.EPS.at(a-1)
#define SYSTEMSTOPADVANCING() (_databox_.SYSTEMOFF=true);
#define STOPADVANCING() SYSTEMSTOPADVANCING()
#define SYSTEMNOTADVANCING (_databox_.SYSTEMOFF)
#define SOLVINGPROBLEM (_databox_.solving)
#define PRESET()  {_databox_.PRESET = true;}
#define NOPRESET() {_databox_.PRESET=false;}
#define _NEQ (_A_0_.size())
#define INITSOLV() {_databox_.INITSOLV=true;}
#define _SETINIT if(NEWIND <=1)
#define CFONSTOP() (_databox_.CFONSTOP = true);

template <class type> void report(type a) {
  std::cout << "from report " << a << std::endl;
}

template <class type1, class type2> void report(type1 a, type2 b) {
  std::cout << a << " " << b << std::endl;
}
template <class type1, class type2> void report(type1 a, type2 b, type2 c) {
  std::cout << a << " " << b << " " << c<< std::endl;
}
template <class type1, class type2>
  void report(type1 a, type2 b, type2 c, type2 d) {
  std::cout << a << " " << b << " " << c<< " " << d<< std::endl;
}
#endif
