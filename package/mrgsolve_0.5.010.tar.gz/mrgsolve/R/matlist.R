## This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
## To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/ or send a letter to
## Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.



##' Manipulate OMEGA and SIGMA matrices.
##'
##' These functions are used to set and get
##' OMEGA and SIGMA matlist objects.
##'
##' @param x a list of matrices
##' @param ... passed to other functions, including \code{\link{modMATRIX}}
##' @param strict passed to \code{\link{merge.list}}
##' @export
##' @name matlist
##' @rdname matlist
##' @aliases omat smat
##' @examples
##' ## example("omat")
##' ## example("smat")
##' ## NOTE: smat works just like omat
##' mat1 <- matrix(1)
##' mat2 <- diag(c(1,2,3))
##' mat3 <- matrix(c(0.1, 0.002, 0.002, 0.5), 2,2)
##' mat4 <- dmat(0.1, 0.2, 0.3, 0.4)
##'
##' omat(mat1)
##' omat(mat1, mat2, mat3)
##' omat(A=mat1, B=mat2, C=mat3)
##'
##' mod <- mrgsolve:::house() %>% omat(mat4)
##'
##' omat(mod)
##' omat(mod, make=TRUE)
##'
setGeneric("omat",function(x,...) standardGeneric("omat"))
##' @export
##' @rdname matlist
setMethod("omat", "missing", function(...) {
    x <- list(...)
    if(length(x)==0) return(create_matlist(class="omegalist"))
    omat(lapply(x,as.matrix))
})

##' @export
##' @rdname matlist
setMethod("omat", "matrix", function(x,...) {
    omat(c(list(x),list(...)))
})


##' @export
##' @rdname matlist
setMethod("omat", "list", function(x,...) {
    create_matlist(x,class="omegalist",...)
})

##' @export
##' @rdname matlist
setMethod("omat", "omegalist", function(x,...) {return(x)})

##' @export
##' @rdname matlist
setGeneric("zero.re", function(x,...) standardGeneric("zero.re"))

call_ZERO <- function(x) .Call("mrgsolve_ZERO",x, PACKAGE="mrgsolve")
ZERO_MATRIX <- function(x) diag(nrow(x))


##' @export
##' @rdname matlist
setMethod("zero.re", "mrgmod", function(x,...) {

    what <- as.character(eval(substitute(alist(...))))
    if(length(what)==0) what <- c("omega", "sigma")
    if(is.element("omega", what)) x <- update(x,omega=lapply(nrow(omat(x)),diag,x=0))
    if(is.element("sigma", what)) x <- update(x,sigma=lapply(nrow(smat(x)),diag,x=0))
    return(x)
})

##' @export
##' @rdname matlist
setGeneric("drop.re", function(x,...) standardGeneric("drop.re"))
##' @export
##' @rdname matlist
setMethod("drop.re", "mrgmod", function(x,...) {

    what <- as.character(eval(substitute(alist(...))))
    if(length(what)==0) what <- c("omega", "sigma")
    if(is.element("omega", what)) x@omega <- new("omegalist")
    if(is.element("sigma", what)) x@sigma <- new("sigmalist")

    return(x)
})




##' @export
##' @rdname matlist
##' @param make logical; if TRUE, matrix list is rendered into a single matrix
setMethod("omat", "mrgmod", function(x,...,make=FALSE,strict=TRUE) {

    args <- list(...)
    if(length(args)>0) return(update(x, omega=omat(...), strict=strict))

    if(!make) return(x@omega)
    as.matrix(x@omega)
})


##' @export
##' @rdname matlist
setGeneric("smat",function(x,...) standardGeneric("smat"))
##' @export
##' @rdname matlist
setMethod("smat", "missing", function(...) {
    x <- list(...)
    if(length(x)==0) return(create_matlist(class="omegalist"))
    smat(lapply(x,as.matrix))
})


##' @export
##' @rdname matlist
setMethod("smat", "matrix", function(x,...) smat(c(list(x),list(...))))
##' @export
##' @rdname matlist
setMethod("smat", "list", function(x,...) {
    create_matlist(x,class="sigmalist",...)
})
##' @export
##' @rdname matlist
setMethod("smat", "sigmalist", function(x,...) return(x))


##' @export
##' @rdname matlist
setMethod("smat", "mrgmod", function(x,...,make=FALSE,strict=TRUE) {

    args <- list(...)
    if(length(args)>0) return(update(x, sigma=smat(...), strict=strict))
    if(!make) return(x@sigma)
    as.matrix(x@sigma)
})



##' @export
##' @rdname matlist
setMethod("smat", "mrgsims", function(x,make=FALSE,...) {

    if(!make) return(mod(x)@sigma)
    as.matrix(mod(x)@sigma)
})
##' @export
##' @rdname matlist
setMethod("omat", "mrgsims", function(x,make=FALSE,...) {
    if(!make) return(mod(x)@omega)
    as.matrix(mod(x)@omega)
})
##' @export
##' @rdname matlist
setMethod("as.list", "matlist", function(x, ...) x@data)
##' @export
##' @rdname matlist
setMethod("as.matrix", "matlist", function(x,...) {
    SUPERMATRIX(x@data,...)
})

##' @rdname matlist
setMethod("names", "matlist", function(x) names(x@data))
##' @rdname matlist
setMethod("length", "matlist", function(x) length(x@data))

##' @export
##' @rdname matlist
setMethod("dim", "matlist", function(x)  lapply(x@data, dim))
##' @export
##' @rdname matlist
setMethod("nrow", "matlist", function(x) unlist(lapply(x@data, nrow)))


##' @export
##' @rdname matlist
##' @param object passed to showmatlist
setMethod("show", "matlist", function(object) showmatlist(object))
showmatlist <- function(x,...) {

    if(length(x@data)==0) {
        cat("No matrices found\n")
        return(invisible(NULL))
    }

    tot <- cumsum(unlist(lapply(x@data, ncol)))

    out <- mapply(x@data,tot,SIMPLIFY=FALSE, FUN=function(out,y) {
        index <- paste0((y-ncol(out)+(1:ncol(out))),": ")
        if(nrow(out) > 0) dimnames(out) <- list(index,colnames(out))
        return(out)

    })
    print(out)
    return(invisible(NULL))
}

cumoffset <- function(x) {

    off <- sapply(as.list(x), nrow)
    if(length(off)==0) return(integer(0))
    ans <- cumsum(c(0,off[-length(off)]))
    names(ans) <- names(x)
    ans
}

setGeneric("rename",function(x,...) standardGeneric("rename"))
setMethod("rename", "matlist", function(x,names,...) {
    names(x@data) <- names
    return(x)
})

setGeneric("gettag", function(x,...) standardGeneric("gettag"))
setMethod("gettag", "matlist", function(x,...) {
    return(names(x@data))
})




