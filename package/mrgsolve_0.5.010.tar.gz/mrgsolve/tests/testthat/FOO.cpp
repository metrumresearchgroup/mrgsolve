

$CMTN DEPOT

$PARAM CL=1, VC=20

$INIT CENT=0 , DEPOT=0

$FIXED A=1.1, B=2.2

$PARAM KM = 2, VMAX=100

$FIXED  
C = 3.3, D=4.4, E = 5.5

$MAIN double Z = A+B+C+D+E;

$TABLE table(cmtn) = _N_DEPOT;
 
