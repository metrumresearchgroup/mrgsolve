
$PARAM CL=1, VC=20, KA=1.1
$CMT GUT CENT
$ADVAN2
$MAIN
pred_CL = CL;
pred_V = VC;
pred_KA = KA;
 
