
#library(metrumrg)
library(testthat)
#library(MASS)
library(mrgsolve)



Sys.setenv(R_TESTS="")

mrgsolve:::comp_forget()
rm(list=ls())

context("Setting F and ALAG")

code <- '
$PARAM F1=1, ALAG1=0, F2=1, ALAG2=0
$INIT CENT=0 , DEPOT=0

$MAIN
_ALAG(1) = ALAG1;
_F(1) = F1;
_ALAG(2) = ALAG2;
_F(2) = F2;

'

ev1 <- ev(amt=100, cmt=1)
ev2 <- ev(amt=100, cmt=2,time=1)

mod <- mread(code=code,model="YSY", warn=FALSE) %>% 
  carry.out(evid) %>% 
  update(end=2)

mod1 <- mod %>% ev(ev1)
mod2 <- mod %>% ev(ev2)

out10 <- mod1 %>% mrgsim()
out11 <- mod1 %>% param(F1 = 0.2) %>% mrgsim() 
out12 <- mod1 %>% param(F1 = 0.8) %>% mrgsim()
out13 <- mod1 %>% param(ALAG1 = 1) %>% mrgsim()
out14 <- mod1 %>% param(ALAG1 = 0.5) %>% mrgsim()

out20 <- mod2 %>% mrgsim() 
out21 <- mod2 %>% param(F2 = 0.3) %>% mrgsim()
out22 <- mod2 %>% param(F2 = 0.1) %>% mrgsim()
out23 <- mod2 %>% param(ALAG2 = 0.3) %>% mrgsim()
out24 <- mod2 %>% param(ALAG2 = 2) %>% mrgsim()


test_that("F is set for compartment 1 and 2", {
    expect_true(limit(out10,time==2)$CENT==100)
    expect_true(limit(out11,time==2)$CENT==20)
    expect_true(limit(out12,time==2)$CENT==80)
    
    expect_true(limit(out20,time==2)$DEPOT==100)
    expect_true(limit(out21,time==2)$DEPOT==30)
    expect_true(limit(out22,time==2)$DEPOT==10)
})

test_that("ALAG is set for compartment 1 and 2", {
  
  expect_true(limit(out10, evid==1)$time==0)
  expect_true(limit(out13, evid==1)$time==1)
  expect_true(limit(out14, evid==1)$time==0.5)
  
  expect_true(limit(out20 ,evid==1)$time==1)
  expect_true(limit(out23,evid==1)$time==1.3)
  expect_true(limit(out24,evid==1)$time==3)
})


out15 <- mod1 %>% ev(amt=100, cmt=1, addl=3, ii=1) %>% param(F1 = 1) %>% mrgsim(end=3)
out16 <- mod1 %>% ev(amt=100, cmt=1, addl=3, ii=1) %>% param(F1 = 0.2) %>% mrgsim(end=3)

test_that("F is set for multiple doses", {
    expect_equivalent(limit(out15, time > 0)$CENT, c(100,200,300))
    expect_equivalent(limit(out16, time > 0)$CENT, c(20,40,60))
})


idata <- mrgsolve:::expand.idata(ID=1:3, F1=c(0.2, 0.5), ALAG1=c(0.2, 0.5,0.7,0.99))
out17 <- mod1 %>% ev(amt=100, cmt=1, time=1) %>% idata_set(idata) %>% mrgsim()
out18 <- mod1 %>% ev(amt=100, cmt=1, time=1) %>% idata_set(idata) %>% mrgsim()


test_that("F and ALAG are set from idata", {
    expect_equivalent(limit(out17, time==2)$CENT, 100*idata$F1)
    expect_equivalent(limit(out18, evid==1)$time, 1+idata$ALAG1)
})

data(exTheoph)
exTheoph$FORM <- as.integer(exTheoph$ID >5)
exTheoph$F1 <- mrgsolve:::mapvalues(exTheoph$FORM, c(0,1), c(0.8, 0.3))
exTheoph$ALAG1 <- mrgsolve:::mapvalues(exTheoph$FORM, c(0,1), c(1.2, 1.8))
doses <- subset(exTheoph, evid==1)


out19 <- mod1 %>% data_set(exTheoph) %>% mrgsim() 
out20 <- mod1 %>% data_set(exTheoph) %>% mrgsim() 

test_that("F  and ALAG are set from data", {
   expect_equivalent(limit(out19, !duplicated(ID, fromLast=TRUE))$CENT, doses$amt*doses$F1)
   expect_equivalent(limit(out20, evid==1)$time, doses$time+doses$ALAG1)
})


