$PARAM  KA = 0.2, CL = 1, VC = 10, FE = 1
$INIT  GUT = 0, CENT = 0, URINE = 0

$ODE
double CLe = FE*CL;
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CL/VC)*CENT;
dxdt_URINE = (CLe/VC)*CENT;

$TABLE
table(CP) = CENT/VC;

