## This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
## To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/ or send a letter to
## Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.

##' @include utils.R

utils::globalVariables(c(".", "name"))

tags <- c("delta", "end","rtol", "atol", "maxsteps", "hmax", "digits","add","defdose","include","getcmtn")
any_tag <- parens(paste(tags, collapse="|"))
tags_re <- paste0("^\\s*//\\s*@",any_tag, ":\\s*")

init_block <- "\\s*/\\*\\%\\s*@init:\\s*"
init_line <- "^\\s*//\\s*@init:\\s*"
param_block <- gsub("init", "param", init_block)
param_line <- gsub("init", "param", init_line)

end_block <- "\\s*\\%\\*/\\s*$"
s_comma_s <- "\\s*,\\s*"
eol.comment <- "^([^#]*)\\#+.*$"
wstrim <- "^\\s+|\\s+$"
wsbegin <- "^\\s+"
wsend <- "\\s+$"

scrub_line <- paste(init_line, param_line,wsbegin,wsend,sep="|")
scrub_block <- paste(init_block,param_block,end_block,wstrim, sep="|")
scrub_block_all <- paste(init_block,param_block,end_block,eol.comment, sep="|")

txt2list <- function(x) {
   if(length(x) > 1)  x <- paste(x, collapse=',')
   x <- paste0("list(", x, ")")
   eval(parse(text=x))
}
parse_block <- function(x,txt) {
  txt <- txt[x$start:x$end]
  txt <- gsub(eol.comment,"\\1",txt)
  txt <- gsub(scrub_block,"",txt)
  txt <- txt[!grepl("^\\s*$", txt,perl=TRUE)]
  txt <- unlist(strsplit(txt,s_comma_s))
  if(length(txt)==0) return(data.frame())
  data.frame(value=txt,source="block")
}
parse_line <- function(x,txt) {
  txt <- txt[x$start]
  txt <- gsub(eol.comment,"\\1",txt)
  txt <- gsub(scrub_line,"",txt)
  txt <- txt[!grepl("^\\s*$", txt,perl=TRUE)]
  txt <- unlist(strsplit(txt,s_comma_s))
  if(length(txt)==0) return(data.frame())
  data.frame(value=txt,source="line")
}

try_parse_attributes <- function(data,crump=TRUE) {
    if(!requireNamespace("plyr", quitely=TRUE)) stop("plyr could not be found; please install from CRAN.")
  check <- plyr::ddply(data, c("start","end","value"), function(x) {
    out <- try(txt2list(x$value),TRUE)
    ret <- NULL
    if(class(out)=="try-error") {
      ret <- data.frame(start=x$start,end=x$end,name=x$name,value=x$value,message=out[1])
    }
    return(ret)
  })
  if(nrow(check)>0) {
      if(crump) stop(check$message)
      if(!crump) message(check$message)
  }
  return(invisible(NULL))
}


## @title Generate table of attributes found in model file
## @param x either character stem of \code{.cpp} model file or an \code{mrgmod} model object.
## @param ... passed along
## @aliases model_attributes model_attributes.mrgmod model_attributes.character
## @name model_attributes
## @return Table of model attributes
setGeneric("model_attributes", function(x,...) standardGeneric("model_attributes"))

## @param project project directory
## @param try.eval logical; if true, \code{mrgsolve} will attempt to evaluate arguments
## @param crump if \code{try.eval} is true, should the program stop of evaluation fails
## @rdname model_attributes
setMethod("model_attributes", "character",  function(x,project=getwd(),try.eval=TRUE,crump=FALSE,...) {

    if(!requireNamespace("plyr",quitely=TRUE)) stop("plyr could not be found; please install from CRAN")

    target <- filename(project,x, ".cpp")

    if(!file.exists(target)) stop("Could not find model file: ", target)

    con <- file(target,open="r")
    txt <- readLines(con,warn=FALSE)
    close(con)
    header <- paste(x, ".h", sep="")

    headerre <- paste0("\\#include\\s+\"",header, "\"")
    if(!any(grepl(headerre, txt))) stop("Could not find proper include directive in model file: \n      ", paste("#include \"",header,"\"", sep=""))



    param_lines <- grep(param_line,txt)
    init_lines <- grep(init_line,txt)

    line <- data.frame(start=c(param_lines, init_lines))
    line$name <- rep(c("param", "init"), c(length(param_lines),length(init_lines)))


    param_blocks <- grep(param_block,txt)
    init_blocks <- grep(init_block,txt)
    end_blocks <- grep(end_block,txt)
    block <- data.frame(start=c(param_blocks,init_blocks))
    block$name <- rep(c("param", "init"), c(length(param_blocks), length(init_blocks)))
    block <- block[order(block$start),]
    if(!(length(end_blocks)==nrow(block))) stop("Parsing attribute blocks: could not match every start with end.")
    block$end <- end_blocks


    df_block <- plyr::ddply(block, .(start,end,name), parse_block,txt)
    df_line <- plyr::ddply(line, .(start,name), parse_line, txt)

    data <- rbind_fill(df_block,df_line)

    tag_pos <- grep(tags_re, txt)
    if(length(tag_pos)>0) {
        tag_txt <- txt[tag_pos]
        tag_txt <- gsub(eol.comment, "\\1", tag_txt)
        tag_labels <- regmatches(tag_txt, regexpr(any_tag,tag_txt))
        tag_txt <- gsub(tags_re, "", tag_txt)
        tag_data <- data.frame(start=tag_pos, end=NA, name="data", value=paste(tag_labels,tag_txt,sep="="), source="line")
        data <- rbind(data,tag_data)
    }

    if(nrow(data)==0) return(data.frame(start=0,end=0,name=0,value=0,source='.')[0,])

    if(try.eval) try_parse_attributes(data,crump=crump)




    data <- data[order(data$start),]

    return(data)
})

## @rdname model_attributes
setMethod("model_attributes", "mrgmod", function(x,...) {
    model_attributes(dllname(x),project(x),...)
})


## @title Pull model attributes from file
## @param model stem of .cpp model file
## @param project project directory
## @param try.eval logical; if true, \code{mrgsolve} will attempt to evaluate arguments
## @param crump if \code{try.eval} is true, should the program stop of evaluation fails
## @return list containing parameter and initial condition lists from the .cpp file
##
pull_attributes <- function(model, project=getwd(),try.eval=TRUE,crump=TRUE) {

    ret <- list(param=list(), init=list())

    data <- model_attributes(model,project,try.eval=try.eval,crump=crump)

    data <- data[order(data$start),]

    init <- txt2list(subset(data, data$name=="init")$value)
    param <- txt2list(subset(data, data$name=="param")$value)

    args <- txt2list(subset(data, data$name=="data")$value)


    if(length(init) > 0) ret$init <- init
    if(length(param)>0) ret$param <- param
    ret$data <- args
    return(ret)
}





