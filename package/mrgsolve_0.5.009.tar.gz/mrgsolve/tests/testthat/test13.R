library(mrgsolve)
library(testthat)
require(dplyr)

Sys.setenv(R_TESTS="")


project <- file.path(system.file(package="mrgsolve"), "models")

context("Compare ADVAN 2 with equivalent ODEs.")

ode <- mrgsolve:::house() %>% param(Q = 0,CL=1,VC=20,KA=1.1)

code <- '
$PARAM CL=1, VC=20, KA=1.1
$CMT GUT CENT
$ADVAN2
$MAIN
pred_CL = CL;
pred_V = VC;
pred_KA = KA;
'
comp_forget()
pred <- mread(code=code, model="test13.1")


out1a <- ode  %>% init(GUT=1000) %>% 
  Req(GUT,CENT) %>% mrgsim(end=24,delta=0.1 ,digits=5)
out1b <- pred %>% init(GUT=1000) %>% 
  Req(GUT,CENT) %>% mrgsim(end=24,delta=0.1,digits=5)

test_that("ADVAN2 same as ODE - initial condition", {
    expect_equal(out1a$CENT,out1b$CENT)
    expect_equal(names(out1a),names(out1b))
})

e <- ev(amt=100,ii=48,addl=4)
out2a <- ode  %>% ev(e) %>% 
  Req(GUT,CENT) %>% mrgsim(end=264,delta=0.1 ,digits=5)
out2b <- pred %>% ev(e) %>% 
  Req(GUT,CENT) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN2 same as ODE - GUT,bolus,addl", {
  expect_equal(out2a$CENT,out2b$CENT)
})


e <- ev(amt=1000,rate=50,ii=48,addl=4)
out3a <- ode  %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1 ,digits=5,hmax=0.1,atol=1E-12,rtol=1E-12)
out3b <- pred %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN2 same as ODE - GUT,infus,addl", {
  expect_equal(out3a$CENT,out3b$CENT)
})

e <- ev(amt=1000,rate=50,ii=48,addl=4,cmt=2)
out4a <- ode  %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1 ,digits=5,hmax=0.1,atol=1E-12,rtol=1E-12)
out4b <- pred %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN2 same as ODE - CENT,infus,addl", {
  expect_equal(out4a$CENT,out4b$CENT)
})

e <- ev(amt=1000,rate=50,ii=48,addl=4,cmt=2,ss=1)
out5a <- ode  %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1 ,digits=5,hmax=0.1,atol=1E-12,rtol=1E-12)
out5b <- pred %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN2 same as ODE - CENT,infus,ss,addl", {
  expect_equal(out5a$CENT,out5b$CENT)
})


e <- ev(amt=1000,ii=12,addl=16,cmt=1,ss=1)
out6a <- ode  %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1 ,digits=5,
                       hmax=0.1,atol=1E-12,rtol=1E-12)
out6b <- pred %>% ev(e) %>% 
  Req(CENT) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN2 same as ODE - GUT,bolus,ss,addl", {
  expect_equal(out6a$CENT,out6b$CENT)
})



project <- file.path(system.file(package="mrgsolve"), "models")

context("Compare ADVAN 4 with equivalent ODEs.")

pred_code <- '
$PARAM CL=1, VC=20, Q=4, KA=1.1, VP=300
$CMT GUT CENT PER
$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - CENT*(CL+Q)/VC + PER*Q/VP;
dxdt_PER = CENT*Q/VC - PER*Q/VP;
'

ode_code <- '
$PARAM CL=1, VC=20, KA=1.1, Q=4, VP=300
$CMT GUT CENT PER
$ADVAN4
$MAIN
pred_CL = CL;
pred_V2 = VC;
pred_KA = KA;
pred_Q = Q;
pred_V3 = VP;
'
comp_forget()

ode <- mread(code=ode_code, model="test13.2") 
pred <- mread(code=pred_code, model="test13.3")


out1a <- ode  %>% init(GUT=1000) %>% 
  Req(GUT,CENT) %>% mrgsim(end=24,delta=0.1 ,digits=5)
out1b <- pred %>% init(GUT=1000) %>% 
  Req(GUT,CENT) %>% mrgsim(end=24,delta=0.1,digits=5)

test_that("ADVAN4 same as ODE - initial condition", {
  expect_equal(out1a$CENT,out1b$CENT)
  expect_equal(names(out1a),names(out1b))
})

e <- ev(amt=100,ii=48,addl=4)
out2a <- ode  %>% ev(e) %>% 
  Req(GUT,CENT,PER) %>% mrgsim(end=264,delta=0.1 ,digits=5)
out2b <- pred %>% ev(e) %>% 
  Req(GUT,CENT,PER) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN4 same as ODE - GUT,bolus,addl", {
  expect_equal(out2a$CENT,out2b$CENT)
  expect_equal(out2a$PER,out2b$PER)
})


e <- ev(amt=1000,rate=50,ii=48,addl=4)
out3a <- ode  %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1 ,digits=5,hmax=0.1,atol=1E-12,rtol=1E-12)
out3b <- pred %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN4 same as ODE - GUT,infus,addl", {
  expect_equal(out3a$CENT,out3b$CENT)
  expect_equal(out3a$PER,out3b$PER)
})

e <- ev(amt=1000,rate=50,ii=48,addl=4,cmt=2)
out4a <- ode  %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1 ,digits=5,hmax=0.1,atol=1E-12,rtol=1E-12)
out4b <- pred %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN4 same as ODE - CENT,infus,addl", {
  expect_equal(out4a$CENT,out4b$CENT)
  expect_equal(out4a$PER,out4b$PER)
})

e <- ev(amt=1000,rate=50,ii=48,addl=4,cmt=2,ss=1)
out5a <- ode  %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1 ,digits=5,hmax=0.1,atol=1E-12,rtol=1E-12)
out5b <- pred %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN4 same as ODE - CENT,infus,ss,addl", {
  expect_equal(out5a$CENT,out5b$CENT)
  expect_equal(out5a$PER,out5b$PER)
})


e <- ev(amt=1000,ii=12,addl=16,cmt=1,ss=1)
out6a <- ode  %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1 ,digits=5,
                       hmax=0.1,atol=1E-12,rtol=1E-12)
out6b <- pred %>% ev(e) %>% 
  Req(CENT,PER) %>% mrgsim(end=264,delta=0.1,digits=5)

test_that("ADVAN4 same as ODE - GUT,bolus,ss,addl", {
  expect_equal(out6a$CENT,out6b$CENT)
  expect_equal(out6a$PER,out6b$PER)
})

context("Check $CMT/$INIT specification with ADVAN2/4")
test_that("No compartments generates error", {
  expect_error(mod <- mread(code="$ADVAN2", model="a2error"))
  expect_error(mod <- mread(code="$ADVAN4", model="a2error"))
})

test_that("Incorrect number of compartments causes error", {
  expect_error(mod <- mread(code="$ADVAN2\n$CMT A", model="a2error"))
  expect_error(mod <- mread(code="$ADVAN4\n$CMT A B C D", model="a2error"))
})

test_that("Correct number of compartments causes no error", {
  expect_is(mread(code="$ADVAN2\n$CMT A B", model="a2error"),"mrgmod")
  expect_is(mread(code="$ADVAN4\n$CMT A B C", model="a2error"),"mrgmod")
})




