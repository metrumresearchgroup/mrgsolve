
$PARAM CL=1, VC=20, KA=1.1, Q=4, VP=300
$CMT GUT CENT PER
$ADVAN4
$MAIN
pred_CL = CL;
pred_V2 = VC;
pred_KA = KA;
pred_Q = Q;
pred_V3 = VP;
 
