library(mrgsolve)
library(testthat)
require(dplyr)

Sys.setenv(R_TESTS="")

project <- file.path(system.file(package="mrgsolve"), "models")

context("Testing infusion inputs")

code <-'

$PARAM CL=1, VC=30, KA=1.2, SET=7
$CMT GUT CENT

$MAIN 
_R(1) =  SET;

$OMEGA
0

$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CL/VC)*CENT;
'

mod <- mread(code=paste0(code), model="infusion") %>%
  update(end=72) %>% obsonly


data <- expand.ev(ID=1:5,rate=c(1,5,10,50), amt=100)
set.seed(1212)
out0 <- mod %>% data_set(data) %>% mrgsim

data <- data %>% mutate(SET = rate, rate=-1)
set.seed(1212)
out <- mod %>% data_set(data) %>% mrgsim



test_that("Infusion rate is set by _R(n)", {
    expect_identical(out0$CENT, out$CENT)
})

data$rate <- -2
test_that("Error when rate = -2 and _R(n) set instead of _D(n)", {
    expect_error(mod %>% data_set(data) %>% mrgsim)
})



code <-'

$PARAM CL=1, VC=30, KA=1.2, SET=0
$CMT GUT CENT

$MAIN 
_D(1) =  SET;

$OMEGA
0

$ODE
dxdt_GUT = -KA*GUT;
dxdt_CENT = KA*GUT - (CL/VC)*CENT;
'


mod <- mread(code=code, model="_D") %>%
  update(end=120) %>% obsonly


data0 <- expand.ev(ID=1:3,dur=c(2,5,10,50), amt=100) %>%
  mutate(rate = amt/dur)

set.seed(1212)
out0 <- mod %>% data_set(data0) %>% mrgsim

data <- data0 %>% mutate(SET = dur, rate=-2)
set.seed(1212)
out <- mod %>% data_set(data) %>% mrgsim

test_that("Infusion rate is set by _D(n)", {
  expect_identical(out0$CENT, out$CENT)
})

data$rate <- -1
test_that("Error when rate = -1 and _D(n) set instead of _R(n)", {
  expect_error(mod %>% data_set(data) %>% mrgsim)
})



