## This work is licensed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International License.
## To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-nd/4.0/ or send a letter to
## Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.


##' Get THETA, OMEGA and SIGMA from a completed NONMEM run
##'
##' @param run run number
##' @param project project directory
##' @param file the complete path to the run.xml file
##' @param theta logical; if TRUE, the $THETA vector is returned
##' @param omega logical; if TRUE, the $OMEGA matrix is returned
##' @param sigma logical; if TRUE, the $SIGMA matrix is returned
##' @param name a character vector or comma-separated string of names for THETA, OMEGA, and SIGMA; use \code{.} for no name
##' @param ... passed along
##' @details
##' If \code{run} and \code{project} are supplied, the .xml file is assumed to be located in \code{run.xml}, in directory \code{run} off the \code{project} directory.  If \code{file} is supplied, \code{run} and \code{project} arguments are ignored.
##' @return a list with theta, omega and sigma elements, depending on what was requested
nmxml <- function(run=numeric(0), project=character(0),
                  file=character(0),
                  theta=TRUE,omega=FALSE,sigma=FALSE,
                  name="THETA,.,.",...) {

    if(!requireNamespace("XML")) stop("Could not load namespace for package XML.", call.=FALSE)

    check.names <- !missing(name)

    name <- as.cvec(name)
    name[name=='.'] <- ""

    if(length(name)!=3) stop("While parsing xml file:\n   length of name must be 3")


    if(check.names) {
        if(missing(theta)) theta <- nchar(name[1])>0
        if(missing(omega)) omega <- nchar(name[2])>0
        if(missing(sigma)) sigma <- nchar(name[3])>0
    }

    if(!missing(file)) {
        target <- file
    } else {
        if(missing(run) | missing(project)) stop("Both file and run/project are missing")
        target <- file.path(project, run, paste0(run, ".xml"))
    }

    tree <-XML::xmlParse(readLines(target), asText = TRUE, error = NULL)

    th <- list()
    om <- omat(matrix(0,0,0))
    sg <- smat(matrix(0,0,0))

    if(theta) {
        th <-XML::xpathSApply(tree, "//nm:theta/nm:val", fun = XML::xmlValue)
        th <- as.list(as.numeric(th))
        names(th) <- paste0(name[1], 1:length(th))
    }

    if(omega) {
        om <- XML::xpathSApply(tree,'//nm:omega/nm:row/nm:col', fun= XML::xmlValue)
        om <- lower2matrix(om)
        om <- rename(omat(om), names=name[2])
    }

    if(sigma) {
        sg <- XML::xpathSApply(tree, "//nm:sigma/nm:row/nm:col", fun=XML::xmlValue)
        sg <- lower2matrix(sg)
        sg <- rename(smat(sg), names=name[3])
    }

    XML::free(tree)

    ans <- list(theta=as.param(th), omega=om,sigma=sg)

    class(ans) <- "NMXMLDATA"

    return(ans)
}

