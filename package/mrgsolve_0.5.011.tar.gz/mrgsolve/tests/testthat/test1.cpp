#include "test1.h" 

// @param: CL=1, VC=2
// @init: CENT=0
// @end: 36
// @delta: 0.2

BEGIN_ode
  dxdt_CENT = -(CL/VC)*CENT;
DONE

BEGIN_table table(CP) = CENT/VC;DONE
 
