
$INIT a=1

$OMEGA
1 2 3

$SIGMA 
1 2

$SIGMA 
2

 
